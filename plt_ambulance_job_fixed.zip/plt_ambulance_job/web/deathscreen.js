﻿(()=>{const __plt="JChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKSB7CgogICAgLyoKICAgICAqIFJlYWxpc3RpYyBQUVJTVCB3YXZlZm9ybSDigJQgU1ZHIHZpZXdCb3ggIjAgMCAzNDAgODAiLCBiYXNlbGluZSB5PTU1LgogICAgICogRWFjaCBwYXR0ZXJuIGhhcyBUV08gZnVsbCBjeWNsZXMgKGN5Y2xlMiA9IGN5Y2xlMSBvZmZzZXQgYnkgKzM0MCBvbiBYKQogICAgICogc28gdGhlIDxnIGlkPSJlY2ctc2Nyb2xsIj4gY2FuIHNjcm9sbCBmcm9tIDAg4oaSIC0zNDAgYW5kIGxvb3Agc2VhbWxlc3NseS4KICAgICAqCiAgICAgKiBPbmUgY3ljbGUgPSAzNDBweCB3aWRlICDihpIgIDMgYmVhdHMsIGVhY2ggfjExMHB4IGFwYXJ0LgogICAgICogUCB3YXZlICA6IHNtYWxsIGdlbnRsZSBidW1wICAoKzhweCBhYm92ZSBiYXNlbGluZSkKICAgICAqIFEgICAgICAgOiB0aW55IGRpcCAgICAgICAgICAgKCs0cHggYmVsb3cpCiAgICAgKiBSIHNwaWtlIDogc2hhcnAgcGVhayAgICAgICAgICg1MHB4IGFib3ZlIGJhc2VsaW5lIOKAlCBtYWluIFFSUyBjb21wbGV4KQogICAgICogUyAgICAgICA6IG92ZXJzaG9vdCBiZWxvdyAgICAoN3B4IGJlbG93IGJhc2VsaW5lKQogICAgICogVCB3YXZlICA6IHJvdW5kZWQgaHVtcCAgICAgICAoMTFweCBhYm92ZSBiYXNlbGluZSkKICAgICAqLwogICAgY29uc3QgQ1lDTEVfVyA9IDM0MDsgLy8gd2lkdGggb2Ygb25lIGZ1bGwgd2F2ZWZvcm0gY3ljbGUKCiAgICAvLyDilIDilIAgYmVhdCBnZW9tZXRyeSBoZWxwZXJzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgAogICAgZnVuY3Rpb24gYmVhdChveCwgb3ksIHJQZWFrKSB7CiAgICAgICAgLy8gb3ggPSB4LW9mZnNldCBvZiBiZWF0IHN0YXJ0LCBveSA9IGJhc2VsaW5lIHksIHJQZWFrID0gUi1wZWFrIHkKICAgICAgICBjb25zdCBzICA9IChyUGVhayA+IDMwKSA/IDQgOiAyOyAgIC8vIFMgb3ZlcnNob290IHNjYWxlICh3ZWFrZXIgPSBsZXNzKQogICAgICAgIGNvbnN0IHRwID0gb3kgLSBNYXRoLnJvdW5kKChveSAtIHJQZWFrKSAqIDAuMjIpOyAgLy8gVC1wZWFrCiAgICAgICAgcmV0dXJuIFsKICAgICAgICAgICAgW294KzAsICBveV0sICAgICAgICAgIC8vIGJhc2VsaW5lIGxlYWQtaW4gc3RhcnQKICAgICAgICAgICAgW294KzgsICBveV0sICAgICAgICAgIC8vIGZsYXQgYmVmb3JlIFAKICAgICAgICAgICAgW294KzEyLCBveS01XSwgICAgICAgIC8vIFAgd2F2ZSByaXNlCiAgICAgICAgICAgIFtveCsxNiwgb3ktOF0sICAgICAgICAvLyBQIHdhdmUgcGVhawogICAgICAgICAgICBbb3grMjAsIG95LTVdLCAgICAgICAgLy8gUCB3YXZlIGZhbGwKICAgICAgICAgICAgW294KzI0LCBveV0sICAgICAgICAgIC8vIFBSIHNlZ21lbnQKICAgICAgICAgICAgW294KzI4LCBveSs0XSwgICAgICAgIC8vIFEgZGlwCiAgICAgICAgICAgIFtveCszMiwgclBlYWtdLCAgICAgICAvLyBSIHNwaWtlICDihpAgbWFpbiBwZWFrCiAgICAgICAgICAgIFtveCszNiwgb3krN10sICAgICAgICAvLyBTIG92ZXJzaG9vdCBiZWxvdyBiYXNlbGluZQogICAgICAgICAgICBbb3grNDIsIG95XSwgICAgICAgICAgLy8gcmV0dXJuIHRvIGJhc2VsaW5lCiAgICAgICAgICAgIFtveCs1MCwgdHBdLCAgICAgICAgICAvLyBUIHdhdmUgcGVhawogICAgICAgICAgICBbb3grNjIsIG95XSwgICAgICAgICAgLy8gVCB3YXZlIGVuZAogICAgICAgIF0ubWFwKHAgPT4gcC5qb2luKCcsJykpLmpvaW4oJyAnKTsKICAgIH0KCiAgICBmdW5jdGlvbiBidWlsZEN5Y2xlKG9mZnNldFgsIHJQZWFrKSB7CiAgICAgICAgLy8gMyBiZWF0cyBzcGFjZWQgMTEwcHggYXBhcnQgd2l0aGluIHRoZSAzNDBweCB3aW5kb3cKICAgICAgICBjb25zdCBiMSA9IGJlYXQob2Zmc2V0WCArICAgMCwgNTUsIHJQZWFrKTsKICAgICAgICBjb25zdCBiMiA9IGJlYXQob2Zmc2V0WCArIDExMCwgNTUsIHJQZWFrKTsKICAgICAgICBjb25zdCBiMyA9IGJlYXQob2Zmc2V0WCArIDIyMCwgNTUsIHJQZWFrKTsKICAgICAgICAvLyB0cmFpbGluZyBmbGF0IGJhY2sgdG8gZW5kIG9mIGN5Y2xlCiAgICAgICAgY29uc3QgdGFpbCA9IGAke29mZnNldFggKyAyODJ9LDU1ICR7b2Zmc2V0WCArIENZQ0xFX1d9LDU1YDsKICAgICAgICByZXR1cm4gYjEgKyAnICcgKyBiMiArICcgJyArIGIzICsgJyAnICsgdGFpbDsKICAgIH0KCiAgICBjb25zdCBFQ0dfUEFUVEVSTlMgPSB7CiAgICAgICAgLy8gc3Ryb25nOiBzaGFycCBSIGF0IHk9NSAoNTBweCBhYm92ZSBiYXNlbGluZSkKICAgICAgICBzdHJvbmc6IHsKICAgICAgICAgICAgYzE6IGJ1aWxkQ3ljbGUoMCwgICAgICAgNSksCiAgICAgICAgICAgIGMyOiBidWlsZEN5Y2xlKENZQ0xFX1csIDUpLAogICAgICAgIH0sCiAgICAgICAgLy8gd2Vhazogc2hhbGxvdyBSIGF0IHk9MjUgKDMwcHggYWJvdmUgYmFzZWxpbmUpCiAgICAgICAgd2VhazogewogICAgICAgICAgICBjMTogYnVpbGRDeWNsZSgwLCAgICAgICAyNSksCiAgICAgICAgICAgIGMyOiBidWlsZEN5Y2xlKENZQ0xFX1csIDI1KSwKICAgICAgICB9LAogICAgICAgIC8vIGZsYXRsaW5lOiBzdHJhaWdodCBob3Jpem9udGFsCiAgICAgICAgZmxhdGxpbmU6IHsKICAgICAgICAgICAgYzE6IGAwLDU1ICR7Q1lDTEVfV30sNTVgLAogICAgICAgICAgICBjMjogYCR7Q1lDTEVfV30sNTUgJHtDWUNMRV9XICogMn0sNTVgLAogICAgICAgIH0sCiAgICB9OwoKICAgIC8vIOKUgOKUgCBzdGF0ZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAKICAgIGNvbnN0IGFuc3dlcnMgPSB7IGJyZWF0aDogbnVsbCwgcHVsc2U6IG51bGwgfTsKICAgIGxldCB0cmFuc3BvcnRBdmFpbGFibGUgPSBmYWxzZTsKICAgIGxldCB0cmFuc3BvcnRSZW1haW5pbmcgPSAwOwogICAgbGV0IHRyYW5zcG9ydFRpY2tlciA9IG51bGw7CgogICAgZnVuY3Rpb24gYXBwbHlEZWF0aE1vZGUobW9kZSkgewogICAgICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSAobW9kZSA9PT0gJ3VuY29uc2Npb3VzJykgPyAndW5jb25zY2lvdXMnIDogJ2RlYWQnOwogICAgICAgIGNvbnN0IHN0YXR1cyA9ICQoJyNkZWF0aC1zdGF0dXMtdGV4dCcpOwogICAgICAgIGNvbnN0IHRpbWVyTGFiZWwgPSAkKCcjZHMtdGltZXItbGFiZWwnKTsKICAgICAgICBpZiAobm9ybWFsaXplZCA9PT0gJ3VuY29uc2Npb3VzJykgewogICAgICAgICAgICBzdGF0dXMuaHRtbChgPHNwYW4gY2xhc3M9ImRzLXN0YXR1cy1wcmVmaXgiPiR7d2luZG93LmFtYlQoJ3VpX3lvdV9hcmUnLCAnWU9VIEFSRScpfTwvc3Bhbj4gPHNwYW4gY2xhc3M9ImRzLXN0YXR1cy1rZXl3b3JkIj4ke3dpbmRvdy5hbWJUKCd1aV91bmNvbnNjaW91cycsICdVTkNPTlNDSU9VUycpfTwvc3Bhbj5gKTsKICAgICAgICAgICAgdGltZXJMYWJlbC50ZXh0KHdpbmRvdy5hbWJUKCd1aV91bmNvbnNjaW91cycsICdVTkNPTlNDSU9VUycpKTsKICAgICAgICB9IGVsc2UgewogICAgICAgICAgICBzdGF0dXMuaHRtbChgPHNwYW4gY2xhc3M9ImRzLXN0YXR1cy1wcmVmaXgiPiR7d2luZG93LmFtYlQoJ3VpX3lvdV9hcmUnLCAnWU9VIEFSRScpfTwvc3Bhbj4gPHNwYW4gY2xhc3M9ImRzLXN0YXR1cy1rZXl3b3JkIj4ke3dpbmRvdy5hbWJUKCd1aV9kZWFkJywgJ0RFQUQnKX08L3NwYW4+YCk7CiAgICAgICAgICAgIHRpbWVyTGFiZWwudGV4dCh3aW5kb3cuYW1iVCgndWlfY3JpdGljYWwnLCAnQ1JJVElDQUwnKSk7CiAgICAgICAgfQogICAgfQoKICAgIGZ1bmN0aW9uIHJlc2V0UXVlc3Rpb25zKCkgewogICAgICAgIGFuc3dlcnMuYnJlYXRoID0gJ25vJzsgLy8gRGVmYXVsdCBmb3IgYXV0by1zaG93CiAgICAgICAgYW5zd2Vycy5wdWxzZSAgPSAnbm8nOwogICAgICAgICQoJy5kcy1jaG9pY2UnKS5yZW1vdmVDbGFzcygnc2VsZWN0ZWQteWVzIHNlbGVjdGVkLW5vJyk7CiAgICAgICAgJCgnI2RlYXRoLWVjZy1wYW5lbCcpLnJlbW92ZUNsYXNzKCdoaWRkZW4nKTsgLy8gRW5zdXJlIHZpc2libGUKICAgICAgICAkKCcjZWNnLW1vZGUtbGFiZWwnKS50ZXh0KCfigJQnKTsKICAgICAgICBhcHBseUVjZ1BhdHRlcm4oJ2ZsYXRsaW5lJywgZmFsc2UpOwogICAgICAgIHN0b3BUcmFuc3BvcnRDb3VudGRvd24oKTsKICAgICAgICB1cGRhdGVUcmFuc3BvcnRCdXR0b24oZmFsc2UsIDApOwogICAgfQoKICAgIGZ1bmN0aW9uIHVwZGF0ZVRyYW5zcG9ydEJ1dHRvbihhdmFpbGFibGUsIHJlbWFpbmluZykgewogICAgICAgIHRyYW5zcG9ydEF2YWlsYWJsZSA9ICEhYXZhaWxhYmxlOwogICAgICAgIHRyYW5zcG9ydFJlbWFpbmluZyA9IE1hdGgubWF4KDAsIE51bWJlcihyZW1haW5pbmcpIHx8IDApOwogICAgICAgIGNvbnN0IGJ0biA9ICQoJyNkcy1idG4tZ28taG9zcGl0YWwnKTsKICAgICAgICBpZiAodHJhbnNwb3J0QXZhaWxhYmxlKSB7CiAgICAgICAgICAgIGJ0bi5wcm9wKCdkaXNhYmxlZCcsIGZhbHNlKS5odG1sKGA8aSBjbGFzcz0iZmFzIGZhLXRydWNrLW1lZGljYWwiPjwvaT4gJHt3aW5kb3cuYW1iVCgndWlfZ29faG9zcGl0YWxfa2V5JywgJ0dPIFRPIEhPU1BJVEFMIFtZXScpfWApOwogICAgICAgIH0gZWxzZSB7CiAgICAgICAgICAgIGJ0bi5wcm9wKCdkaXNhYmxlZCcsIHRydWUpLmh0bWwoYDxpIGNsYXNzPSJmYXMgZmEtdHJ1Y2stbWVkaWNhbCI+PC9pPiAke3dpbmRvdy5hbWJUKCd1aV9nb19ob3NwaXRhbF93YWl0JywgJ0dPIFRPIEhPU1BJVEFMICh7c2Vjb25kc31zKSBbWV0nLCB7IHNlY29uZHM6IHRyYW5zcG9ydFJlbWFpbmluZyB9KX1gKTsKICAgICAgICB9CiAgICB9CgogICAgZnVuY3Rpb24gc3RvcFRyYW5zcG9ydENvdW50ZG93bigpIHsKICAgICAgICBpZiAodHJhbnNwb3J0VGlja2VyKSB7CiAgICAgICAgICAgIGNsZWFySW50ZXJ2YWwodHJhbnNwb3J0VGlja2VyKTsKICAgICAgICAgICAgdHJhbnNwb3J0VGlja2VyID0gbnVsbDsKICAgICAgICB9CiAgICB9CgogICAgZnVuY3Rpb24gc3RhcnRUcmFuc3BvcnRDb3VudGRvd24oc2Vjb25kcykgewogICAgICAgIHN0b3BUcmFuc3BvcnRDb3VudGRvd24oKTsKICAgICAgICB1cGRhdGVUcmFuc3BvcnRCdXR0b24oc2Vjb25kcyA8PSAwLCBzZWNvbmRzKTsKICAgICAgICBpZiAoc2Vjb25kcyA8PSAwKSByZXR1cm47CiAgICAgICAgdHJhbnNwb3J0VGlja2VyID0gc2V0SW50ZXJ2YWwoKCkgPT4gewogICAgICAgICAgICB0cmFuc3BvcnRSZW1haW5pbmcgPSBNYXRoLm1heCgwLCB0cmFuc3BvcnRSZW1haW5pbmcgLSAxKTsKICAgICAgICAgICAgdXBkYXRlVHJhbnNwb3J0QnV0dG9uKHRyYW5zcG9ydFJlbWFpbmluZyA8PSAwLCB0cmFuc3BvcnRSZW1haW5pbmcpOwogICAgICAgICAgICBpZiAodHJhbnNwb3J0UmVtYWluaW5nIDw9IDApIHsKICAgICAgICAgICAgICAgIHN0b3BUcmFuc3BvcnRDb3VudGRvd24oKTsKICAgICAgICAgICAgfQogICAgICAgIH0sIDEwMDApOwogICAgfQoKICAgIGZ1bmN0aW9uIGFwcGx5RWNnUGF0dGVybihuYW1lLCBpc0FjdGl2ZSkgewogICAgICAgIGNvbnN0IHBhdCAgID0gRUNHX1BBVFRFUk5TW25hbWVdOwogICAgICAgIGNvbnN0IGlzRmwgID0gKG5hbWUgPT09ICdmbGF0bGluZScpOwogICAgICAgICQoJyNlY2ctbGluZScpLmF0dHIoJ3BvaW50cycsICBwYXQuYzEpLnRvZ2dsZUNsYXNzKCdmbGF0bGluZScsIGlzRmwpOwogICAgICAgICQoJyNlY2ctbGluZTInKS5hdHRyKCdwb2ludHMnLCBwYXQuYzIpLnRvZ2dsZUNsYXNzKCdmbGF0bGluZScsIGlzRmwpOwogICAgICAgIC8vIHBhdXNlIHNjcm9sbCBhbmltYXRpb24gZm9yIGZsYXRsaW5lLCBydW4gZm9yIGFjdGl2ZSBwdWxzZQogICAgICAgICQoJyNlY2ctc2Nyb2xsJykudG9nZ2xlQ2xhc3MoJ3BhdXNlZCcsIGlzRmwpOwogICAgfQoKICAgIGZ1bmN0aW9uIGFwcGx5Vml0YWxzKGJyZWF0aGluZywgcHVsc2UpIHsKICAgICAgICBpZiAoIXB1bHNlKSB7CiAgICAgICAgICAgIGFwcGx5RWNnUGF0dGVybignZmxhdGxpbmUnLCBmYWxzZSk7CiAgICAgICAgICAgICQoJyNlY2ctbW9kZS1sYWJlbCcpLnRleHQod2luZG93LmFtYlQoJ3VpX25vX3B1bHNlX2ZsYXRsaW5lJywgJ05PIFBVTFNFIOKAlCBGTEFUTElORScpKTsKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIH0KICAgICAgICBpZiAoYnJlYXRoaW5nICYmIHB1bHNlKSB7CiAgICAgICAgICAgIGFwcGx5RWNnUGF0dGVybignc3Ryb25nJywgdHJ1ZSk7CiAgICAgICAgICAgICQoJyNlY2ctbW9kZS1sYWJlbCcpLnRleHQod2luZG93LmFtYlQoJ3VpX3N0YWJsZV92aXRhbHMnLCAnU1RBQkxFIFZJVEFMUycpKTsKICAgICAgICB9IGVsc2UgewogICAgICAgICAgICBhcHBseUVjZ1BhdHRlcm4oJ3dlYWsnLCB0cnVlKTsKICAgICAgICAgICAgJCgnI2VjZy1tb2RlLWxhYmVsJykudGV4dCh3aW5kb3cuYW1iVCgndWlfd2Vha19wdWxzZScsICdXRUFLIFBVTFNFJykpOwogICAgICAgIH0KICAgIH0KCiAgICBmdW5jdGlvbiBtYXJrQ2hvaWNlKHF1ZXN0aW9uLCBhbnN3ZXIpIHsKICAgICAgICBjb25zdCB5ZXMgPSAkKGAuZHMtY2hvaWNlW2RhdGEtcXVlc3Rpb249IiR7cXVlc3Rpb259Il1bZGF0YS1hbnN3ZXI9InllcyJdYCk7CiAgICAgICAgY29uc3Qgbm8gID0gJChgLmRzLWNob2ljZVtkYXRhLXF1ZXN0aW9uPSIke3F1ZXN0aW9ufSJdW2RhdGEtYW5zd2VyPSJubyJdYCk7CiAgICAgICAgeWVzLnJlbW92ZUNsYXNzKCdzZWxlY3RlZC15ZXMgc2VsZWN0ZWQtbm8nKTsKICAgICAgICBuby5yZW1vdmVDbGFzcygnc2VsZWN0ZWQteWVzIHNlbGVjdGVkLW5vJyk7CiAgICAgICAgaWYgKGFuc3dlciA9PT0gJ3llcycpIHllcy5hZGRDbGFzcygnc2VsZWN0ZWQteWVzJyk7CiAgICAgICAgZWxzZSAgICAgICAgICAgICAgICAgIG5vLmFkZENsYXNzKCdzZWxlY3RlZC1ubycpOwogICAgfQoKICAgIGZ1bmN0aW9uIG1heWJlU2hvd0VjZygpIHsKICAgICAgICAkKCcjZGVhdGgtZWNnLXBhbmVsJykucmVtb3ZlQ2xhc3MoJ2hpZGRlbicpOwogICAgICAgIGFwcGx5Vml0YWxzKGFuc3dlcnMuYnJlYXRoID09PSAneWVzJywgYW5zd2Vycy5wdWxzZSA9PT0gJ3llcycpOwogICAgfQoKICAgIC8vIOKUgOKUgCBidXR0b24gY2xpY2tzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgAogICAgJChkb2N1bWVudCkub24oJ2NsaWNrJywgJy5kcy1jaG9pY2UnLCBmdW5jdGlvbigpIHsKICAgICAgICBjb25zdCBxdWVzdGlvbiA9ICQodGhpcykuZGF0YSgncXVlc3Rpb24nKTsKICAgICAgICBjb25zdCBhbnN3ZXIgICA9ICQodGhpcykuZGF0YSgnYW5zd2VyJyk7CiAgICAgICAgaWYgKCFxdWVzdGlvbiB8fCAhYW5zd2VyKSByZXR1cm47CiAgICAgICAgYW5zd2Vyc1txdWVzdGlvbl0gPSBhbnN3ZXI7CiAgICAgICAgbWFya0Nob2ljZShxdWVzdGlvbiwgYW5zd2VyKTsKICAgICAgICBtYXliZVNob3dFY2coKTsKICAgIH0pOwoKICAgICQoJyNkcy1idG4tY2FsbC1lbXMnKS5vbignY2xpY2snLCBmdW5jdGlvbigpIHsKICAgICAgICBmZXRjaChgaHR0cHM6Ly8ke0dldFBhcmVudFJlc291cmNlTmFtZSgpfS9hbWJfY2FsbEVNU2AsIHsKICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsCiAgICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LAogICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7fSkKICAgICAgICB9KTsKICAgIH0pOwoKICAgICQoJyNkcy1idG4tZ28taG9zcGl0YWwnKS5vbignY2xpY2snLCBmdW5jdGlvbigpIHsKICAgICAgICBpZiAoIXRyYW5zcG9ydEF2YWlsYWJsZSkgcmV0dXJuOwogICAgICAgIGZldGNoKGBodHRwczovLyR7R2V0UGFyZW50UmVzb3VyY2VOYW1lKCl9L2FtYl9nb0hvc3BpdGFsYCwgewogICAgICAgICAgICBtZXRob2Q6ICdQT1NUJywKICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sCiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHt9KQogICAgICAgIH0pOwogICAgfSk7CgogICAgLy8g4pSA4pSAIE5VSSBtZXNzYWdlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAKICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgZnVuY3Rpb24oZXZlbnQpIHsKICAgICAgICBjb25zdCBkYXRhID0gZXZlbnQuZGF0YTsKCiAgICAgICAgaWYgKGRhdGEuYWN0aW9uID09PSAnYW1iX3RvZ2dsZURlYXRoU2NyZWVuJykgewogICAgICAgICAgICBpZiAoZGF0YS5zaG93KSB7CiAgICAgICAgICAgICAgICAkKCcjZGVhdGgtc2NyZWVuLWNvbnRhaW5lcicpLmFkZENsYXNzKCd2aXNpYmxlJyk7CiAgICAgICAgICAgICAgICB1cGRhdGVEZWF0aFRpbWVyKGRhdGEudGltZSk7CiAgICAgICAgICAgICAgICBhcHBseURlYXRoTW9kZShkYXRhLm1vZGUpOwogICAgICAgICAgICAgICAgJCgnLmRzLWhpbnQnKS5yZW1vdmVDbGFzcygnY2FsbGVkJyk7CiAgICAgICAgICAgICAgICAkKCcjaGludC1tZWRpY2FsIC5kcy1oaW50LXRleHQnKS50ZXh0KHdpbmRvdy5hbWJUKCd1aV9ub3RpZnlfbWVkaWNzJywgJ05vdGlmeSBNZWRpY3MnKSk7CiAgICAgICAgICAgICAgICByZXNldFF1ZXN0aW9ucygpOwogICAgICAgICAgICAgICAgbWF5YmVTaG93RWNnKCk7CiAgICAgICAgICAgICAgICBzdGFydFRyYW5zcG9ydENvdW50ZG93bihOdW1iZXIoZGF0YS50cmFuc3BvcnREZWxheSkgfHwgMCk7CiAgICAgICAgICAgIH0gZWxzZSB7CiAgICAgICAgICAgICAgICAkKCcjZGVhdGgtc2NyZWVuLWNvbnRhaW5lcicpLnJlbW92ZUNsYXNzKCd2aXNpYmxlJyk7CiAgICAgICAgICAgICAgICByZXNldFF1ZXN0aW9ucygpOwogICAgICAgICAgICB9CgogICAgICAgIH0gZWxzZSBpZiAoZGF0YS5hY3Rpb24gPT09ICdhbWJfdXBkYXRlRGVhdGhUaW1lcicpIHsKICAgICAgICAgICAgdXBkYXRlRGVhdGhUaW1lcihkYXRhLnRpbWUpOwoKICAgICAgICB9IGVsc2UgaWYgKGRhdGEuYWN0aW9uID09PSAnYW1iX2Vtc0NhbGxlZCcpIHsKICAgICAgICAgICAgJCgnI2hpbnQtbWVkaWNhbCcpLmFkZENsYXNzKCdjYWxsZWQnKTsKICAgICAgICAgICAgJCgnI2hpbnQtbWVkaWNhbCAuZHMtaGludC10ZXh0JykudGV4dCh3aW5kb3cuYW1iVCgndWlfZW1zX25vdGlmaWVkJywgJ0VNUyBOb3RpZmllZCcpKTsKICAgICAgICAgICAgaWYgKGFuc3dlcnMuYnJlYXRoICE9PSBudWxsICYmIGFuc3dlcnMucHVsc2UgIT09IG51bGwpIHsKICAgICAgICAgICAgICAgIGFwcGx5Vml0YWxzKHRydWUsIHRydWUpOwogICAgICAgICAgICB9CiAgICAgICAgfSBlbHNlIGlmIChkYXRhLmFjdGlvbiA9PT0gJ2FtYl90cmFuc3BvcnRTdGF0ZScpIHsKICAgICAgICAgICAgaWYgKGRhdGEuYXZhaWxhYmxlKSB7CiAgICAgICAgICAgICAgICBzdG9wVHJhbnNwb3J0Q291bnRkb3duKCk7CiAgICAgICAgICAgICAgICB1cGRhdGVUcmFuc3BvcnRCdXR0b24odHJ1ZSwgMCk7CiAgICAgICAgICAgIH0gZWxzZSB7CiAgICAgICAgICAgICAgICBzdGFydFRyYW5zcG9ydENvdW50ZG93bihOdW1iZXIoZGF0YS5yZW1haW5pbmcpIHx8IDApOwogICAgICAgICAgICB9CiAgICAgICAgfQogICAgfSk7Cn0pOwoKZnVuY3Rpb24gdXBkYXRlRGVhdGhUaW1lcihzZWNvbmRzKSB7CiAgICBpZiAoc2Vjb25kcyA9PSBudWxsKSByZXR1cm47CiAgICBjb25zdCBtaW5zID0gTWF0aC5mbG9vcihzZWNvbmRzIC8gNjApOwogICAgY29uc3Qgc2VjcyA9IE1hdGguZmxvb3Ioc2Vjb25kcyAlIDYwKTsKICAgICQoJyNkZWF0aC10aW1lcicpLnRleHQoCiAgICAgICAgYCR7U3RyaW5nKG1pbnMpLnBhZFN0YXJ0KDIsICcwJyl9OiR7U3RyaW5nKHNlY3MpLnBhZFN0YXJ0KDIsICcwJyl9YAogICAgKTsKfQo=";const __bytes=Uint8Array.from(atob(__plt),c=>c.charCodeAt(0));(0,eval)(new TextDecoder().decode(__bytes));})();
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// CUSTOM (death system) - the new death UI layer:
//   * YOU ARE DOWN status + critically injured subtitle + WAIT FOR EMS label
//   * KILLED BY block (name / id / weapon), UNKNOWN when no killer
//   * GIVE UP button with the locked countdown state
//   * FINISHED mode hides every action button and shows the final state
// Everything in English.
// ---------------------------------------------------------------------------
(function () {
    'use strict';

    var $ = window.jQuery;

    if (!$) { return; }

    function setKiller(info) {
        var block = $('#death-killer-block');

        if (!info || !info.name || info.src === 0 || info.src === undefined || info.src === null) {
            block.removeClass('hidden');
            $('#death-killer-name').text('UNKNOWN');
            $('#death-killer-meta').html('ID: &mdash; &nbsp;|&nbsp; WEAPON: &mdash;');
            return;
        }

        var name = String(info.name || 'UNKNOWN');
        var id = (info.src === undefined || info.src === null) ? '--' : String(info.src);
        var weapon = String(info.weapon || info.weaponLabel || 'UNKNOWN');

        block.removeClass('hidden');
        $('#death-killer-name').text(name);
        $('#death-killer-meta').html(
            'ID: ' + id + ' &nbsp;|&nbsp; WEAPON: ' + weapon
        );
    }

    function setGiveUp(available, remaining) {
        var btn = $('#ds-btn-give-up');

        if (btn.length === 0) { return; }

        if (available) {
            btn.removeClass('locked');
            btn.html('<i class="fas fa-skull"></i> GIVE UP');
        } else {
            btn.addClass('locked');
            btn.html('<i class="fas fa-lock"></i> GIVE UP LOCKED (' + Math.max(0, Number(remaining) || 0) + 's)');
        }
    }

    function setDownStatus() {
        $('#death-status-text').html(
            '<span class="ds-status-prefix">YOU ARE</span> ' +
            '<span class="ds-status-keyword">DOWN</span>'
        );
        $('#ds-timer-label').text('WAIT FOR EMS');
        $('#ds-headline-sub').text('You have been critically injured.');
    }

    function setFinishedMode(show) {
        $('#ds-btn-call-ems').toggle(!show);
        $('#ds-btn-go-hospital').toggle(!show);
        $('#ds-btn-give-up').toggle(!show);
        $('#hint-medical').toggle(!show);

        if (show) {
            $('#death-status-text').html(
                '<span class="ds-status-prefix">YOU ARE</span> ' +
                '<span class="ds-status-keyword">FINISHED</span>'
            );
            $('#ds-timer-label').text('HOSPITAL RESPAWN IN');
            $('#ds-headline-sub').text('You are finished. You are completely dead.');
            $('#ecg-line').attr('points', '0,55 340,55').addClass('flatline');
            $('#ecg-line2').attr('points', '340,55 680,55').addClass('flatline');
            $('#ecg-scroll').addClass('paused');
            $('#ecg-mode-label').text('NO PULSE - FLATLINE');
        }
    }

    $('#ds-btn-give-up').on('click', function () {
        if ($(this).hasClass('locked')) { return; }

        fetch('https://' + GetParentResourceName() + '/amb_giveUp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        });
    });

    window.addEventListener('message', function (event) {
        var data = event.data;

        if (!data || typeof data.action !== 'string') { return; }

        if (data.action === 'amb_killerInfo') {
            setKiller(data.info);
        } else if (data.action === 'amb_giveUpState') {
            setGiveUp(data.available === true, data.remaining);
        } else if (data.action === 'amb_finishedState') {
            setFinishedMode(data.show !== false);
        } else if (data.action === 'amb_transportAllowed') {
            $('#ds-btn-go-hospital').toggle(data.show !== false);
        } else if (data.action === 'amb_toggleDeathScreen') {
            if (data.show) {
                // Every fresh death screen starts clean; the killer info and
                // the give-up state are pushed by Lua right after.
                setFinishedMode(false);
                setKiller(null);

                if (data.mode === 'unconscious') {
                    setDownStatus();
                }
            } else {
                setFinishedMode(false);
                setKiller(null);
            }
        }
    });
})();
